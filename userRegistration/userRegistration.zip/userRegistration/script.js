const loginPage =()=>{
    window.location.assign(
        "Login.html"
    );
}
const signupPage=()=>{
    window.location =("signUp.html")
}

